<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css"> 
   


</head>
<body>
    
    <header class="header">
    
        <div id="menu-btn" class="fas fa-bars"></div>
    
        <a href="#" class="logo"> <span>Dream</span>Carz </a>
    
        <nav class="navbar">
            <a href="/cars website/index.php">home</a>
            <a href="#vehicles">Cars Available</a>
            <a href="#services">services</a>
            <a href="#featured">Top Cars</a>
            <a href="#reviews">reviews</a>
            <a href="#contact">Customer support</a>
        </nav>
    
        <div id="login-btn">
            <button class="btn">login</button>
            <i class="far fa-user"></i>
        </div>
    
    </header>





<section class="featured" id="featured"><br><br>

    <h1 class="heading"> <span>Cars </span> Available </h1>
    <a href="#"> <i class="fas fa-arrow-right"></i> home </a>
    <div class="swiper featured-slider">

       

            
                <img src="image/car-1.png" alt=""><br><br>
                <div class="content">
                    <h3>new model</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">$55,000/-</div><br><br>
                    <a href="addcar.php" class="btn">Book Now</a><br><br>
                </div>
            

           
                <img src="image/car-2.png" alt=""><br><br>
                <div class="content">
                    <h3>new model</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">$55,000/-</div><br><br>
                    <a href="addcar.php" class="btn">Book Now</a><br><br>
                </div>
            

            
                <img src="image/car-3.png" alt=""><br><br>
                <div class="content">
                    <h3>new model</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">$55,000/-</div><br><br>
                    <a href="addcar.php" class="btn">Book Now</a><br><br>
                </div>
            

            
                <img src="image/car-4.png" alt=""><br><br>
                <div class="content">
                    <h3>new model</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <div class="price">$55,000/-</div><br><br>
                    <a href="addcar.php" class="btn">Book Now</a><br><br>
                </div>
            

       

       <div class="swiper-pagination"></div>

    </div>

    <div class="swiper featured-slider">

        
 
             
                 <img src="image/car-5.png" alt=""><br><br>
                 <div class="content">
                     <h3>new model</h3>
                     <div class="stars">
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star-half-alt"></i>
                     </div>
                     <div class="price">$55,000/-</div><br><br>
                     <a href="addcar.php" class="btn">Book Now</a><br><br>
                 </div>
             
 
             
                 <img src="image/car-6.png" alt=""><br><br>
                 <div class="content">
                     <h3>new model</h3>
                     <div class="stars">
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star-half-alt"></i>
                     </div>
                     <div class="price">$55,000/-</div><br><br>
                     <a href="addcar.php" class="btn">Book Now</a><br><br>
                 </div>
             
 
             
                 <img src="image/car-7.png" alt=""><br><br>
                 <div class="content">
                     <h3>new model</h3>
                     <div class="stars">
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star-half-alt"></i>
                     </div>
                     <div class="price">$55,000/-</div><br><br>
                     <a href="addcar.php" class="btn">Book Now</a><br><br>
                 </div>
             
 
             
                 <img src="image/car-8.png" alt=""><br><br>
                 <div class="content">
                     <h3>new model</h3>
                     <div class="stars">
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star"></i>
                         <i class="fas fa-star-half-alt"></i>
                     </div>
                     <div class="price">$55,000/-</div><br><br>
                     <a href="addcar.php" class="btn">Book Now</a><br><br>
                 </div>
             
 
        
 
        <div class="swiper-pagination"></div>
 
     </div>

</section>
<section class="footer" id="footer">

    <div class="box-container">


        <div class="box">
            <h3>quick links</h3>
            <a href="#"> <i class="fas fa-arrow-right"></i> home </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> vehicles </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> services </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> featured </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> reviews </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> contact </a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +123-456-7890 </a>
            <a href="#"> <i class="fas fa-phone"></i> +111-222-3333 </a>
            <a href="#"> <i class="fas fa-envelope"></i> hellofreewebsitecode@gmail.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> City - Country - 000000 </a>
        </div>

        <div class="box">
            <h3>Follow Us On</h3>
            <a href="https://www.facebook.com/FreeWebsiteCode"> <i class="fab fa-facebook-f"></i> facebook </a>
            <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
            <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
            <a href="#"> <i class="fab fa-pinterest"></i> pinterest </a>
        </div>

    </div>

    <div class="credit"> All rights reserved © 2006-2024 Dream Carz</a> | </div>

</section>










<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<script src="js/script.js"></script>

</body>
</html>